package com.example.avaliao2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etSalario, etFilhos;
    private RadioGroup rgSexo;
    private Button btnCalcular;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Conectando os componentes do layout
        etNome = findViewById(R.id.et_nome);
        etSalario = findViewById(R.id.et_salario);
        etFilhos = findViewById(R.id.et_filhos);
        rgSexo = findViewById(R.id.rg_sexo);
        btnCalcular = findViewById(R.id.btn_calcular);
        tvResultado = findViewById(R.id.tv_resultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularSalario();
            }
        });
    }

    private void calcularSalario() {
        try {
            String nome = etNome.getText().toString();
            double salarioBruto = Double.parseDouble(etSalario.getText().toString());
            int filhos = Integer.parseInt(etFilhos.getText().toString());
            int sexoId = rgSexo.getCheckedRadioButtonId();

            if (nome.isEmpty() || sexoId == -1) {
                Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Definindo o prefixo Sr. ou Sra.
            RadioButton sexoSelecionado = findViewById(sexoId);
            String tratamento = sexoSelecionado.getText().equals("Masculino") ? "Sr." : "Sra.";

            // Cálculo do INSS
            double descontoINSS;
            if (salarioBruto <= 1212.00) {
                descontoINSS = salarioBruto * 0.075;
            } else if (salarioBruto <= 2427.35) {
                descontoINSS = salarioBruto * 0.09;
            } else if (salarioBruto <= 3641.03) {
                descontoINSS = salarioBruto * 0.12;
            } else {
                descontoINSS = salarioBruto * 0.14;
            }

            // Cálculo do IR
            double descontoIR;
            if (salarioBruto <= 1903.98) {
                descontoIR = 0.0;
            } else if (salarioBruto <= 2826.65) {
                descontoIR = salarioBruto * 0.075;
            } else if (salarioBruto <= 3751.05) {
                descontoIR = salarioBruto * 0.15;
            } else if (salarioBruto <= 4664.68) {
                descontoIR = salarioBruto * 0.225;
            } else {
                descontoIR = salarioBruto * 0.275;
            }

            // Cálculo do Salário-Família
            double salarioFamilia = 0;
            if (salarioBruto <= 1212.00) {
                salarioFamilia = filhos * 56.47;
            }

            // Cálculo do salário líquido
            double salarioLiquido = salarioBruto - (descontoINSS + descontoIR) + salarioFamilia;

            // Exibir os resultados
            String resultado = tratamento + " " + nome + "\n" +
                    "INSS: R$ " + String.format("%.2f", descontoINSS) + "\n" +
                    "IR: R$ " + String.format("%.2f", descontoIR) + "\n" +
                    "Salário Líquido: R$ " + String.format("%.2f", salarioLiquido);

            tvResultado.setText(resultado);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Insira valores válidos para salário e número de filhos", Toast.LENGTH_SHORT).show();
        }
    }
}